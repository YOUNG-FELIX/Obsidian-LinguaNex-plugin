/**
 * Cookie Copier v3.6 - background
 * 参考 Edit-This-Cookie / Cookie-Editor 的读取链路：
 *   1. browser_action 点击 -> tabs.query 取当前活动标签页
 *   2. getAllCookieStores 匹配 tab.id 得到 storeId（正确处理普通/隐身窗口）
 *   3. cookies.getAll({url, storeId}) 读取当前站点全部 Cookie（含 HttpOnly）
 *   4. 消息转发给 content script 的悬浮窗
 * 安全：本扩展仅本地读取与复制，无任何网络请求，不留存任何数据。
 */

const MSG_SHOW = 'cookie-copier:show';
const MSG_GET = 'cookie-copier:get';
const MSG_HIDE = 'cookie-copier:hide';

function sendToTab(tabId, type, data, cb) {
  try {
    chrome.tabs.sendMessage(tabId, { type, data }, cb || function () {});
  } catch (e) {
    // 页面尚未就绪或消息发送失败时静默处理
  }
}

function getStoreIdForTab(tabId, cb) {
  chrome.cookies.getAllCookieStores(function (stores) {
    if (!stores) return cb(undefined);
    for (let i = 0; i < stores.length; i++) {
      const ids = stores[i].tabIds || [];
      if (ids.indexOf(tabId) !== -1) {
        cb(stores[i].id);
        return;
      }
    }
    cb(undefined);
  });
}

function fetchCookies(tab, cb) {
  if (!tab || !tab.url) {
    cb({ success: false, error: '无法获取当前标签页 URL' });
    return;
  }
  if (!/^https?:\/\//.test(tab.url)) {
    cb({ success: false, error: '仅支持 http/https 页面（当前：' + tab.url + '）' });
    return;
  }
  getStoreIdForTab(tab.id, function (storeId) {
    const params = { url: tab.url };
    if (storeId) params.storeId = storeId;
    try {
      chrome.cookies.getAll(params, function (cookies) {
        const err = chrome.runtime.lastError;
        if (err) {
          cb({ success: false, error: err.message });
          return;
        }
        cb({ success: true, url: tab.url, cookies: cookies || [] });
      });
    } catch (e) {
      cb({ success: false, error: String(e && e.message || e) });
    }
  });
}

chrome.browserAction.onClicked.addListener(function (tab) {
  // 点击图标 -> 通知当前页显示悬浮窗；其余时间页面不注入、不自动弹出
  sendToTab(tab.id, MSG_SHOW, {});
});

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (!request || !request.type) return;
  if (request.type === MSG_GET) {
    const tabId = (sender && sender.tab && sender.tab.id);
    if (tabId === undefined) {
      // content script 主动请求（如页面加载自动唤起）时退回查询活动标签页
      chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
        fetchCookies(tabs && tabs[0], sendResponse);
      });
      return true;
    }
    fetchCookies(sender.tab, sendResponse);
    return true;
  }
});
