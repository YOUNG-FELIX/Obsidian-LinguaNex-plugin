/**
 * Cookie Copier v3.6 - content
 * 页面内悬浮窗：点击扩展图标后注入显示。
 * 安全要点：
 *  - Shadow DOM 隔离：样式与 DOM 不污染页面、也不受页面样式干扰
 *  - 所有 Cookie 值使用 textContent 渲染，杜绝 HTML 注入/XSS
 *  - 复制仅通过 execCommand + clipboardWrite，数据不离开本机
 *  - 无任何网络请求、无 remote code、无 eval
 */
(function () {
  'use strict';

  const MSG_SHOW = 'cookie-copier:show';
  const MSG_GET = 'cookie-copier:get';
  const MSG_HIDE = 'cookie-copier:hide';
  const HOST_ID = 'cookie-copier-host';

  if (window.top !== window) return; // 仅在顶层 frame 显示，避免重复注入
  if (document.getElementById(HOST_ID)) return;

  // ---------- 复制工具（textarea + execCommand） ----------
  function copyText(text) {
    return new Promise(function (resolve) {
      try {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.setAttribute('readonly', '');
        ta.style.position = 'fixed';
        ta.style.left = '-9999px';
        ta.style.top = '0';
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        ta.setSelectionRange(0, text.length);
        const ok = document.execCommand('copy');
        document.body.removeChild(ta);
        resolve(ok);
      } catch (e) {
        resolve(false);
      }
    });
  }

  // ---------- 格式化 ----------
  function cookiesToJSON(cookies) {
    return JSON.stringify(
      cookies.map(function (c) {
        return { name: c.name, value: c.value, domain: c.domain, path: c.path, secure: c.secure, httpOnly: c.httpOnly, sameSite: c.sameSite, session: c.session, expirationDate: c.expirationDate };
      }),
      null, 2
    );
  }

  function cookiesToHeaderString(cookies) {
    return cookies.map(function (c) { return c.name + '=' + c.value; }).join('; ');
  }

  function maskValue(v) {
    if (v == null) return '';
    const s = String(v);
    if (s.length <= 8) return '••••••••';
    return s.slice(0, 4) + '••••••••' + s.slice(-4);
  }

  // ---------- 悬浮窗 DOM（Shadow DOM 隔离） ----------
  const host = document.createElement('div');
  host.id = HOST_ID;
  host.style.cssText = 'all:initial;position:fixed!important;top:0;left:0;width:0;height:0;z-index:2147483647!important;';
  document.documentElement.appendChild(host);

  const shadow = host.attachShadow({ mode: 'closed' });

  const css = `
:host { all: initial; }
* { box-sizing: border-box; margin: 0; padding: 0; }
.panel {
  --bg: #ffffff; --fg: #1f2328; --border: #d0d7de; --header-bg: #f6f8fa;
  --muted: #57606a; --btn-bg: #ffffff; --btn-hover: #eaeef2; --row-border: #f0f2f4;
  --accent: #0969da; --accent-hover: #0858b8; --err: #cf222e; --empty: #9aa0a6;
  position: fixed; top: 16px; right: 16px; width: 380px; max-width: calc(100vw - 32px);
  max-height: calc(100vh - 32px); display: none; flex-direction: column;
  background: var(--bg); color: var(--fg); border: 1px solid var(--border); border-radius: 10px;
  box-shadow: 0 8px 30px rgba(0,0,0,.18); font: 13px/1.5 -apple-system, "Segoe UI", Roboto, "Microsoft YaHei", sans-serif;
  z-index: 2147483647; overflow: hidden;
}
/* 自动跟随浏览器/系统深色主题（Kiwi 手机端随系统切换） */
@media (prefers-color-scheme: dark) {
  .panel {
    --bg: #1e2227; --fg: #e6edf3; --border: #3d444d; --header-bg: #171b21;
    --muted: #9aa4b0; --btn-bg: #2b3138; --btn-hover: #3a4149; --row-border: #2b3138;
    --accent: #2f81f7; --accent-hover: #4c96f8; --err: #f85149; --empty: #7d8590;
    box-shadow: 0 8px 30px rgba(0,0,0,.5);
  }
}
.panel.dragging { user-select: none; cursor: move; }
.header {
  display: flex; align-items: center; gap: 8px; padding: 10px 12px;
  background: var(--header-bg); border-bottom: 1px solid var(--border); cursor: move; flex: none;
}
.header .title { font-weight: 600; font-size: 13px; flex: 1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.header .badge { font-size: 11px; color: var(--muted); }
.header .btn {
  border: 1px solid var(--border); background: var(--btn-bg); color: var(--fg); border-radius: 6px;
  width: 26px; height: 26px; line-height: 1; cursor: pointer; font-size: 14px; flex: none;
}
.header .btn:hover { background: var(--btn-hover); }
.body { flex: 1; overflow: auto; padding: 8px 12px; }
.toolbar { display: flex; gap: 6px; padding: 8px 12px; border-bottom: 1px solid var(--row-border); flex-wrap: wrap; }
.toolbar .btn {
  border: 1px solid var(--border); background: var(--btn-bg); border-radius: 6px; padding: 5px 10px;
  cursor: pointer; font-size: 12px; color: var(--fg); flex: none;
}
.toolbar .btn.primary { background: var(--accent); border-color: var(--accent); color: #fff; }
.toolbar .btn:hover { background: var(--btn-hover); }
.toolbar .btn.primary:hover { background: var(--accent-hover); }
.toolbar .btn:disabled { opacity: .5; cursor: not-allowed; }
.status { font-size: 12px; color: var(--muted); padding: 0 12px 8px; min-height: 16px; }
.list { }
.row {
  display: flex; align-items: center; gap: 8px; padding: 6px 4px; border-bottom: 1px solid var(--row-border);
}
.row .name { font-weight: 600; min-width: 96px; max-width: 130px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: none; }
.row .val { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: var(--muted); cursor: pointer; }
.row .meta { color: var(--empty); font-size: 11px; flex: none; }
.row .copy {
  border: 1px solid var(--border); background: var(--btn-bg); border-radius: 6px; padding: 2px 8px;
  cursor: pointer; font-size: 11px; color: var(--fg); flex: none;
}
.row .copy:hover { background: var(--btn-hover); }
.empty { color: var(--empty); text-align: center; padding: 24px 0; }
.err { color: var(--err); font-size: 12px; padding: 8px 0; }
.dot {
  position: fixed; right: -9px; bottom: 24%; width: 16px; height: 16px; border-radius: 50%;
  background: var(--fg); opacity: 0.14; pointer-events: none; z-index: 2147483647;
}
.dot.active { display: block; }
`;

  const styleEl = document.createElement('style');
  styleEl.textContent = css;
  shadow.appendChild(styleEl);

  const dot = document.createElement('div');
  dot.className = 'dot';
  shadow.appendChild(dot);

  const panel = document.createElement('div');
  panel.className = 'panel';
  panel.innerHTML = '';
  shadow.appendChild(panel);

  // header
  const header = document.createElement('div');
  header.className = 'header';
  const title = document.createElement('div');
  title.className = 'title';
  title.textContent = 'Cookie Copier';
  const badge = document.createElement('div');
  badge.className = 'badge';
  const btnMin = document.createElement('button');
  btnMin.className = 'btn';
  btnMin.textContent = '–';
  btnMin.title = '最小化';
  const btnClose = document.createElement('button');
  btnClose.className = 'btn';
  btnClose.textContent = '×';
  btnClose.title = '关闭';
  header.appendChild(title);
  header.appendChild(badge);
  header.appendChild(btnMin);
  header.appendChild(btnClose);
  panel.appendChild(header);

  // toolbar
  const toolbar = document.createElement('div');
  toolbar.className = 'toolbar';
  const btnCopyJSON = document.createElement('button');
  btnCopyJSON.className = 'btn primary';
  btnCopyJSON.textContent = '复制全部(JSON)';
  const btnCopyHeader = document.createElement('button');
  btnCopyHeader.className = 'btn';
  btnCopyHeader.textContent = '复制全部(Cookie串)';
  const btnRefresh = document.createElement('button');
  btnRefresh.className = 'btn';
  btnRefresh.textContent = '刷新';
  toolbar.appendChild(btnCopyJSON);
  toolbar.appendChild(btnCopyHeader);
  toolbar.appendChild(btnRefresh);
  panel.appendChild(toolbar);

  // status
  const status = document.createElement('div');
  status.className = 'status';
  panel.appendChild(status);

  // list
  const list = document.createElement('div');
  list.className = 'list';
  panel.appendChild(list);

  let cookies = [];
  let minimized = false;

  function setStatus(msg) {
    status.textContent = msg;
  }

  function render() {
    list.textContent = '';
    if (!cookies || cookies.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty';
      empty.textContent = '当前页面没有 Cookie';
      list.appendChild(empty);
      return;
    }
    cookies.forEach(function (c) {
      const row = document.createElement('div');
      row.className = 'row';

      const nameEl = document.createElement('div');
      nameEl.className = 'name';
      nameEl.textContent = c.name;
      nameEl.title = c.name + '（HttpOnly）';
      row.appendChild(nameEl);

      const valEl = document.createElement('div');
      valEl.className = 'val';
      valEl.textContent = maskValue(c.value);
      valEl.title = '点击显示/隐藏完整值';
      let shown = false;
      valEl.addEventListener('click', function () {
        shown = !shown;
        valEl.textContent = shown ? c.value : maskValue(c.value);
      });
      row.appendChild(valEl);

      const meta = document.createElement('div');
      meta.className = 'meta';
      meta.textContent = (c.httpOnly ? 'H' : '') + (c.secure ? ' S' : '');
      meta.title = 'H=HttpOnly S=Secure';
      row.appendChild(meta);

      const btnCopy = document.createElement('button');
      btnCopy.className = 'copy';
      btnCopy.textContent = '复制';
      btnCopy.addEventListener('click', async function () {
        const ok = await copyText(c.name + '=' + c.value);
        setStatus(ok ? '已复制：' + c.name : '复制失败');
      });
      row.appendChild(btnCopy);

      list.appendChild(row);
    });
  }

  async function load() {
    setStatus('读取中…');
    try {
      const resp = await new Promise(function (resolve) {
        chrome.runtime.sendMessage({ type: MSG_GET }, function (r) {
          resolve(r || { success: false, error: chrome.runtime.lastError && chrome.runtime.lastError.message || '无响应' });
        });
      });
      if (!resp || !resp.success) {
        list.textContent = '';
        const errEl = document.createElement('div');
        errEl.className = 'err';
        errEl.textContent = '读取失败：' + ((resp && resp.error) || '未知错误');
        list.appendChild(errEl);
        setStatus('');
        return;
      }
      cookies = resp.cookies;
      badge.textContent = resp.url.replace(/^https?:\/\//, '').replace(/\/.*$/, '');
      setStatus('共 ' + cookies.length + ' 个 Cookie（值默认打码，点击显示）');
      render();
    } catch (e) {
      setStatus('读取异常：' + String(e && e.message || e));
    }
  }

  // ---------- 拖动 ----------
  let drag = null;
  function onPointerDown(e) {
    if (e.target.closest && e.target.closest('.btn')) return;
    drag = { dx: e.clientX - panel.getBoundingClientRect().left, dy: e.clientY - panel.getBoundingClientRect().top };
    panel.classList.add('dragging');
  }
  function onPointerMove(e) {
    if (!drag) return;
    let x = e.clientX - drag.dx;
    let y = e.clientY - drag.dy;
    const rect = panel.getBoundingClientRect();
    x = Math.min(Math.max(x, 0), window.innerWidth - rect.width);
    y = Math.min(Math.max(y, 0), window.innerHeight - rect.height);
    panel.style.left = x + 'px';
    panel.style.top = y + 'px';
  }
  function onPointerUp() {
    drag = null;
    panel.classList.remove('dragging');
  }
  header.addEventListener('mousedown', onPointerDown);
  window.addEventListener('mousemove', onPointerMove);
  window.addEventListener('mouseup', onPointerUp);

  // ---------- 按钮 ----------
  btnCopyJSON.addEventListener('click', async function () {
    if (!cookies.length) return;
    const ok = await copyText(cookiesToJSON(cookies));
    setStatus(ok ? '已复制 ' + cookies.length + ' 个 Cookie（JSON 格式）' : '复制失败');
  });
  btnCopyHeader.addEventListener('click', async function () {
    if (!cookies.length) return;
    const ok = await copyText(cookiesToHeaderString(cookies));
    setStatus(ok ? '已复制 ' + cookies.length + ' 个 Cookie（name=value; 串）' : '复制失败');
  });
  btnRefresh.addEventListener('click', load);
  btnMin.addEventListener('click', function () {
    minimized = !minimized;
    panel.style.display = minimized ? 'none' : 'flex';
    btnMin.textContent = minimized ? '+' : '–';
  });
  btnClose.addEventListener('click', function () {
    collapse();
  });

  // ---------- 显示 ----------
  function show() {
    dot.style.display = 'none';
    minimized = false;
    panel.style.display = 'flex';
    btnMin.textContent = '–';
    load();
  }

  // 收起：回到常驻悬浮球（面板消失，页面不残留大弹窗）
  function collapse() {
    panel.style.display = 'none';
    dot.style.display = 'block';
  }

  // ---------- 消息 ----------
  chrome.runtime.onMessage.addListener(function (request) {
    if (!request || !request.type) return;
    if (request.type === MSG_SHOW) {
      show();
    } else if (request.type === MSG_HIDE) {
      collapse();
    }
  });

  // 说明：注入后仅显示一个贴边半透明小圆点（几乎不可见、不可点击、不读取任何数据）。
  // 只有点击扩展图标（background 发来 MSG_SHOW）才展开完整面板；点叉/MSG_HIDE 收起回小圆点。
  // 刷新页面后回到小圆点状态，绝不会自动弹出大面板。
})();
